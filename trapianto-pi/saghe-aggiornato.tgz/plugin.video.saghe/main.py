# -*- coding: utf-8 -*-
"""Le Saghe - punto di ingresso del plugin."""

import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import abbonamenti, catalogo, fonti, progresso, russo as russo_lib, schede, ponte_s4me

ADDON = xbmcaddon.Addon()
MANIGLIA = int(sys.argv[1])
BASE = sys.argv[0]

PAGINA = 100  # tappe per pagina quando si sfoglia


def url(**kwargs):
    return BASE + "?" + urlencode(kwargs)


def _voce(etichetta, descrizione="", cartella=True, url_voce=None,
          icona="DefaultVideo.png", riproducibile=False):
    li = xbmcgui.ListItem(label=etichetta)
    li.setArt({"icon": icona, "thumb": icona})
    tag = li.getVideoInfoTag()
    tag.setTitle(etichetta)
    if descrizione:
        tag.setPlot(descrizione)
    if riproducibile:
        li.setProperty("IsPlayable", "true")
    return li


# --------------------------------------------------------------------------
# Menu principale
# --------------------------------------------------------------------------

def menu_principale():
    xbmcplugin.setPluginCategory(MANIGLIA, "Le Saghe")

    for pid in catalogo.ORDINE_PERCORSI:
        p = catalogo.PERCORSI[pid]
        totale = catalogo.lunghezza(pid)
        idx = progresso.posizione(pid)
        fatto = progresso.percentuale(pid, totale)
        quanti_visti = len(progresso.visti(pid))

        if quanti_visti == 0:
            stato = "%d episodi - mai cominciata" % totale
        else:
            stato = "%d%% vista - %d episodi su %d" % (fatto, quanti_visti, totale)

        li = _voce("%s\n[COLOR grey]%s[/COLOR]" % (p["titolo"], stato),
                   "%s\n\nSei arrivato a: %s" % (
                       p["sottotitolo"],
                       catalogo.descrizione_segmento(pid, idx)))
        prima = p["segmenti"][0][0]
        arte = {}
        if schede.poster(prima):
            arte["poster"] = arte["thumb"] = arte["icon"] = schede.poster(prima)
        if schede.sfondo(prima):
            arte["fanart"] = schede.sfondo(prima)
        if arte:
            li.setArt(arte)
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="percorso", percorso=pid), li, True)

    cop, tot, perc = abbonamenti.copertura()
    li = _voce("I miei abbonamenti\n[COLOR grey]con quello che hai vedi il "
               "%d%% di tutto[/COLOR]" % perc,
               "Cosa ti sblocca ogni abbonamento, in episodi veri.",
               icona="DefaultAddonService.png")
    xbmcplugin.addDirectoryItem(
        MANIGLIA, url(azione="abbonamenti"), li, True)

    li = _voce("Russo con i cartoni\n[COLOR grey]%d canali per bambini, in ordine di difficolta'[/COLOR]"
               % len(russo_lib.CANALI),
               "I cartoni per bambini piccoli sono la cosa piu' vicina a un "
               "corso di lingua che ci sia in TV: parlano lentamente, "
               "ripetono, e le immagini spiegano le parole.",
               icona="DefaultAddonLanguage.png")
    xbmcplugin.addDirectoryItem(MANIGLIA, url(azione="russo"), li, True)

    an = progresso.anomalie()
    if an:
        li = _voce("[COLOR red]Attenzione: %d episodi sbagliati[/COLOR]" % len(an),
                   "È partito un episodio diverso da quello scelto.",
                   icona="DefaultAddonNone.png")
        xbmcplugin.addDirectoryItem(MANIGLIA, url(azione="anomalie"), li, False)

    xbmcplugin.endOfDirectory(MANIGLIA)


def pannello_abbonamenti():
    cop, tot, perc = abbonamenti.copertura()
    xbmcplugin.setPluginCategory(MANIGLIA, "I miei abbonamenti")

    li = _voce("[B]Oggi puoi vedere %d episodi su %d  (%d%%)[/B]"
               % (cop, tot, perc),
               "Conteggio su tutte le saghe, esclusa la via veloce di Dragon "
               "Ball che e' un doppione.", icona="DefaultAddonService.png")
    xbmcplugin.addDirectoryItem(MANIGLIA, url(azione="abbonamenti"), li, False)

    for v in abbonamenti.riepilogo():
        if v["posseduta"]:
            segno = "[COLOR green]HAI[/COLOR]"
            nota = "ti da %d episodi" % v["episodi"]
        elif v["esclusivi"]:
            segno = "[COLOR orange]TI MANCA[/COLOR]"
            nota = "sbloccherebbe %d episodi che oggi non puoi vedere" % v["esclusivi"]
        else:
            segno = "[COLOR grey]non serve[/COLOR]"
            nota = "i suoi %d episodi li hai gia altrove" % v["episodi"]

        li = _voce("%s  %s\n[COLOR grey]%s - %s[/COLOR]"
                   % (segno, v["nome"], nota, v["prezzo"]),
                   "%s\n\n%s\nPrezzo: %s" % (v["nome"], nota, v["prezzo"]))
        lg = fonti.logo(v["id"])
        if lg:
            li.setArt({"icon": lg, "thumb": lg})
        xbmcplugin.addDirectoryItem(MANIGLIA, url(azione="abbonamenti"), li, False)

    li = _voce("Cambia i miei abbonamenti...",
               "Apre le impostazioni per spuntare cosa possiedi.",
               icona="DefaultAddonProgram.png")
    xbmcplugin.addDirectoryItem(MANIGLIA, url(azione="impostazioni"), li, False)
    xbmcplugin.endOfDirectory(MANIGLIA)


# --------------------------------------------------------------------------
# Menu di un percorso
# --------------------------------------------------------------------------

def menu_percorso(pid):
    p = catalogo.PERCORSI[pid]
    totale = catalogo.lunghezza(pid)
    idx = progresso.posizione(pid)
    secondi, durata = progresso.ripresa(pid)
    mai = len(progresso.visti(pid)) == 0

    xbmcplugin.setPluginCategory(MANIGLIA, p["titolo"])

    # 1. La voce che serve nel 90% dei casi.
    dove = catalogo.descrizione_segmento(pid, idx).split(" - ")[0]
    if mai:
        testo = "Comincia dal primo episodio"
    else:
        testo = "Riprendi da: %s" % dove
        if secondi > 60:
            testo += "  (al minuto %s)" % _mmss(secondi)
    li = _voce("[B]%s[/B]" % testo,
               "Parte subito l'episodio giusto, senza cercare nulla.",
               riproducibile=True, icona="DefaultInProgressShows.png")
    xbmcplugin.addDirectoryItem(
        MANIGLIA, url(azione="riproduci", percorso=pid, idx=idx), li, False)

    # 2. Tutti gli episodi.
    li = _voce("Tutti gli episodi in ordine\n[COLOR grey]%d, dal primo "
               "all'ultimo[/COLOR]" % totale,
               "L'ordine corretto per capire la storia, anche quando salta da "
               "una serie all'altra.", icona="DefaultTVShows.png")
    xbmcplugin.addDirectoryItem(
        MANIGLIA, url(azione="sfoglia", percorso=pid, da=1), li, True)

    # 2-bis. I capitoli. In 659 tappe non si trova piu' niente: senza questa
    # voce, per sapere dove sono gli episodi con Jiren bisogna contare a mano.
    archi = catalogo.archi_di(pid)
    if archi:
        dove = catalogo.arco_della_tappa(pid, progresso.posizione(pid))
        li = _voce("Vai a un capitolo\n[COLOR grey]%d capitoli%s[/COLOR]"
                   % (len(archi), (" - sei in: " + dove) if dove else ""),
                   "Salta direttamente all'arco che ti interessa, senza "
                   "scorrere centinaia di episodi.", icona="DefaultTags.png")
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="capitoli", percorso=pid), li, False)

    # 3. I film.
    fl = schede.film(pid)
    if fl:
        disp = sum(1 for m in fl
                   if any(fonti.possiede(f) for f in m.get("f", [])))
        li = _voce("I film\n[COLOR grey]%d, di cui %d guardabili adesso[/COLOR]"
                   % (len(fl), disp),
                   "Lungometraggi e special. Stanno fuori dall'ordine: "
                   "raccontano storie a se'.", icona="DefaultMovies.png")
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="film", percorso=pid), li, True)

    # 4. I tagli italiani.
    quanti = len(catalogo.tutti_i_tagli(pid))
    if quanti:
        li = _voce("Dove la TV italiana ti ha interrotto\n[COLOR grey]%d punti"
                   "[/COLOR]" % quanti,
                   "Gli episodi esatti in cui hanno tagliato o smesso di "
                   "trasmettere.", icona="DefaultAddonNone.png")
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="tagli", percorso=pid), li, True)

    # 5. Tutto il resto, raccolto.
    li = _voce("[COLOR grey]Altro...[/COLOR]",
               "Com'e' fatto questo ordine, riparti da un punto preciso, "
               "ricomincia da capo.", icona="DefaultAddonHelper.png")
    xbmcplugin.addDirectoryItem(
        MANIGLIA, url(azione="altro", percorso=pid), li, True)

    xbmcplugin.endOfDirectory(MANIGLIA)


def menu_altro(pid):
    xbmcplugin.setPluginCategory(MANIGLIA, "Altro")
    voci = [
        ("Com'e' fatto questo ordine", "spiega",
         "Perche' gli episodi sono in quest'ordine e non un altro.",
         "DefaultAddonHelper.png", False),
        ("Riparti da un episodio preciso...", "salta",
         "Scegli tu il punto da cui ricominciare.",
         "DefaultAddonsSearch.png", False),
        ("Ricomincia da capo", "azzera",
         "Riporta la saga al primo episodio e cancella cosa hai visto.",
         "DefaultAddonNone.png", False),
    ]
    for etichetta, azione, desc, icona, cartella in voci:
        li = _voce(etichetta, desc, icona=icona)
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione=azione, percorso=pid), li, cartella)
    xbmcplugin.endOfDirectory(MANIGLIA)


def _mmss(secondi):
    m, s = divmod(int(secondi), 60)
    h, m = divmod(m, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


# --------------------------------------------------------------------------
# Sfoglia la catena
# --------------------------------------------------------------------------

def sfoglia(pid, da):
    tappe = catalogo.catena(pid)
    totale = len(tappe)
    da = max(1, min(int(da), totale))
    fine = min(da + PAGINA - 1, totale)
    gia_visti = progresso.visti(pid)
    corrente = progresso.posizione(pid)

    xbmcplugin.setPluginCategory(
        MANIGLIA, "%s - %d-%d di %d" % (
            catalogo.PERCORSI[pid]["titolo"], da, fine, totale))

    if da > 1:
        li = _voce("[COLOR grey]' Indietro[/COLOR]")
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="sfoglia", percorso=pid,
                          da=max(1, da - PAGINA)), li, True)

    for t in tappe[da - 1:fine]:
        serie = catalogo.SERIE[t["serie"]]
        fonte = fonti.fonte_migliore(t["serie"], t["ep"])

        segno = ""
        if t["idx"] in gia_visti:
            segno = "[COLOR green]v[/COLOR] "
        elif t["idx"] == corrente:
            segno = "[COLOR yellow]>[/COLOR] "

        tagli = catalogo.tagli_di(t["serie"], t["ep"])
        if tagli:
            segno = "[COLOR red]*[/COLOR] " + segno

        coda = ""
        if fonte is None:
            # NIENTE etichetta rossa: da quando c'e' il ripiego su s4me
            # l'episodio si vede lo stesso, quindi "non disponibile" era una
            # bugia che sporcava tutta la lista. Chi non ha una fonte fra gli
            # abbonamenti semplicemente non porta nessuna sigla.
            coda = ""
        elif fonte["id"] == "locale":
            coda = "  [COLOR green]- tuo file[/COLOR]"
        else:
            sg = fonti.sigla(fonte["id"])
            if sg:
                colore = "99FF9E4D" if catalogo.FONTI[fonte["id"]]["gratis"]                     else "997FA8D8"
                coda = "  [COLOR %s]- %s[/COLOR]" % (colore, sg)

        sch = schede.episodio(t["serie"], t["ep"])
        nome = sch["titolo"] or t["etichetta"]
        etichetta = "%s%04d. %s%s" % (segno, t["idx"], nome, coda)

        descrizione = "%s\n\n%s" % (
            catalogo.descrizione_segmento(pid, t["idx"]), serie["nota"])
        if not serie["verificato"]:
            descrizione += ("\n\n[COLOR yellow]Il numero di episodi di questa "
                            "serie non e' ancora stato confermato alla "
                            "fonte.[/COLOR]")
        if fonte:
            descrizione += "\n\nPartirà da: %s" % fonte["etichetta"]
        for tg in tagli:
            descrizione += "\n\n[COLOR red]* TAGLIO ITALIANO[/COLOR]\n%s" % tg["cosa"]

        li = _voce(etichetta, descrizione, riproducibile=True)
        arte = {}
        if sch["immagine"]:
            arte["thumb"] = sch["immagine"]
        if fonte and fonte["id"] != "locale":
            lg = fonti.logo(fonte["id"])
            if lg:
                arte["clearlogo"] = lg
                arte["icon"] = lg
        po = schede.poster(t["serie"])
        if po:
            arte["poster"] = po
        sf = schede.sfondo(t["serie"])
        if sf:
            arte["fanart"] = sf
        if arte:
            li.setArt(arte)
        tag = li.getVideoInfoTag()
        tag.setMediaType("episode")
        tag.setTvShowTitle(serie["titolo"])
        tag.setEpisode(t["ep"])
        if sch["titolo"]:
            tag.setTitle(sch["titolo"])
        if sch["trama"]:
            tag.setPlot(descrizione)
        if sch["data"]:
            tag.setFirstAired(sch["data"])
        if t["idx"] in gia_visti:
            tag.setPlaycount(1)

        li.addContextMenuItems([
            ("Riparti da qui",
             "RunPlugin(%s)" % url(azione="vai", percorso=pid, idx=t["idx"])),
            ("Segna come visto",
             "RunPlugin(%s)" % url(azione="visto", percorso=pid, idx=t["idx"])),
            ("Segna come non visto",
             "RunPlugin(%s)" % url(azione="nonvisto", percorso=pid, idx=t["idx"])),
        ])

        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="riproduci", percorso=pid, idx=t["idx"]),
            li, False)

    if fine < totale:
        li = _voce("[COLOR grey]Avanti '[/COLOR]")
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="sfoglia", percorso=pid, da=fine + 1), li, True)

    xbmcplugin.setContent(MANIGLIA, "episodes")
    xbmcplugin.endOfDirectory(MANIGLIA)


# --------------------------------------------------------------------------
# Riproduzione
# --------------------------------------------------------------------------

def riproduci(pid, idx):
    idx = int(idx)
    t = catalogo.tappa(pid, idx)
    if not t:
        xbmcgui.Dialog().notification("Le Saghe", "Tappa inesistente",
                                      xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(MANIGLIA, False, xbmcgui.ListItem())
        return

    serie = catalogo.SERIE[t["serie"]]
    fonte = fonti.fonte_migliore(t["serie"], t["ep"])

    if fonte is None:
        _spiega_fonte_mancante(t, serie)
        xbmcplugin.setResolvedUrl(MANIGLIA, False, xbmcgui.ListItem())
        return

    progresso.vai_a(pid, idx)

    # --- Riproduzione dentro Kodi: si registra il minuto ---
    if fonte["tipo"] == "locale":
        secondi, durata = progresso.ripresa(pid)
        li = xbmcgui.ListItem(path=fonte["percorso"])
        tag = li.getVideoInfoTag()
        tag.setTitle(t["etichetta"])
        tag.setTvShowTitle(serie["titolo"])
        tag.setEpisode(t["ep"])
        tag.setMediaType("episode")
        if secondi > 0 and durata > 0:
            li.setProperty("ResumeTime", str(secondi))
            li.setProperty("TotalTime", str(durata))
        progresso.apri_sessione(
            pid, idx, dentro_kodi=True,
            atteso="%s ep %d" % (serie["titolo"], t["ep"]),
            file_atteso=fonte["percorso"])
        xbmcplugin.setResolvedUrl(MANIGLIA, True, li)
        return

    # --- App Android: Kodi non vede il video, quindi non vede il minuto ---
    if fonte["tipo"] == "app":
        pacchetto = catalogo.FONTI[fonte["id"]]["pacchetto"]
        link = fonti.link_diretto(fonte["id"], t["serie"])
        progresso.apri_sessione(pid, idx, dentro_kodi=False,
                                atteso="%s ep %d" % (serie["titolo"], t["ep"]))
        xbmcgui.Dialog().notification(
            "Le Saghe",
            "%s - cerca l'episodio %d" % (serie["titolo"], t["ep"]),
            xbmcgui.NOTIFICATION_INFO, 7000)
        fonti.avvia_app(pacchetto, link)
        xbmcplugin.setResolvedUrl(MANIGLIA, False, xbmcgui.ListItem())
        return

    # --- Altro addon di Kodi ---
    xbmcgui.Dialog().ok(
        "Le Saghe",
        "Questa fonte ([B]%s[/B]) passa da un altro addon che non è ancora "
        "collegato.\n\nÈ il prossimo pezzo da costruire." % fonte["etichetta"])
    xbmcplugin.setResolvedUrl(MANIGLIA, False, xbmcgui.ListItem())


def _spiega_fonte_mancante(t, serie):
    elenco = fonti.fonti_disponibili(t["serie"], t["ep"])
    if not elenco:
        testo = ("Per questa serie non è ancora configurata nessuna fonte.")
    else:
        nomi = ", ".join(f["etichetta"] for f in elenco)
        testo = ("[B]%s - episodio %d[/B]\n\n"
                 "Questo episodio esiste su: %s\n\n"
                 "Nessuna di queste è fra i tuoi abbonamenti. Puoi attivarne "
                 "uno, oppure indicare nelle impostazioni la cartella con i "
                 "tuoi file: la fonte locale ha sempre la precedenza e "
                 "nessuno può togliertela." % (serie["titolo"], t["ep"], nomi))
    # Invece di lasciare l'utente davanti a un muro: gli si offre di cercarlo
    # su s4me senza uscire da qui. Il titolo viene passato gia' scritto, cosi'
    # non deve ridigitarlo col telecomando.
    titolo_ricerca = ponte_s4me.titolo_per_ricerca(serie, t)
    if ponte_s4me.installato() and titolo_ricerca:
        scelta = xbmcgui.Dialog().yesno(
            "Fonte non disponibile",
            testo + "\n\n[B]Vuoi cercarlo su s4me?[/B]",
            nolabel="No, chiudi",
            yeslabel="Cerca '%s'" % titolo_ricerca)
        if scelta:
            # Prima si PROVA a farlo partire da solo: e' quello che l'utente
            # vuole davvero (non vedere la lista, vedere l'episodio).
            # Se non si riesce a decidere, apri_automatico porta comunque al
            # punto piu' profondo raggiunto, invece di lasciarlo alla ricerca.
            esito = ponte_s4me.apri_automatico(titolo_ricerca, t["ep"])
            if esito == "niente":
                ponte_s4me.cerca(titolo_ricerca)
            elif esito == "avvicinato":
                xbmcgui.Dialog().notification(
                    "Le Saghe",
                    "Non ho individuato l'episodio %d: eccoti al punto piu' vicino"
                    % t["ep"], xbmcgui.NOTIFICATION_INFO, 5000)
            return
    else:
        xbmcgui.Dialog().textviewer("Fonte non disponibile", testo)


# --------------------------------------------------------------------------
# Azioni secondarie
# --------------------------------------------------------------------------

def russo():
    """I canali russi per bambini, dal piu' facile al piu' difficile."""
    xbmcplugin.setPluginCategory(MANIGLIA, "Russo con i cartoni")

    li = _voce("Come usarli davvero\n[COLOR grey]Leggi prima questo[/COLOR]",
               russo_lib.CONSIGLIO, icona="DefaultAddonHelp.png")
    xbmcplugin.addDirectoryItem(MANIGLIA, url(azione="russo_consiglio"), li, False)

    for _liv, titolo_liv, canali in russo_lib.per_livello():
        for c in canali:
            li = _voce("%s\n[COLOR grey]%s - %s[/COLOR]" % (c["nome"], titolo_liv, c["eta"]),
                       "%s\n\n%s\n\n[B]Eta' a cui e' rivolto:[/B] %s"
                       % (c["nome"], c["perche"], c["eta"]),
                       icona="DefaultTVShows.png", riproducibile=True)
            xbmcplugin.addDirectoryItem(
                MANIGLIA, url(azione="russo_guarda", canale=c["id"]), li, False)

    xbmcplugin.endOfDirectory(MANIGLIA)


def russo_consiglio():
    xbmcgui.Dialog().textviewer("Russo con i cartoni", russo_lib.CONSIGLIO)


def russo_guarda(cid):
    """Manda in onda il canale scelto. Sono flussi diretti: Kodi li apre."""
    c = russo_lib.canale(cid)
    if not c:
        xbmcplugin.setResolvedUrl(MANIGLIA, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=c["url"])
    tag = li.getVideoInfoTag()
    tag.setTitle(c["nome"])
    tag.setPlot(c["perche"])
    tag.setMediaType("video")
    xbmcplugin.setResolvedUrl(MANIGLIA, True, li)


def capitoli(pid):
    """Elenco dei capitoli della saga: si sceglie e ci si sposta li'."""
    archi = catalogo.archi_di(pid)
    if not archi:
        return
    corrente = progresso.posizione(pid)
    righe = []
    for nome, da, a in archi:
        segno = "[COLOR yellow]  <- sei qui[/COLOR]" if da <= corrente <= a else ""
        righe.append("%s   [COLOR grey](tappe %d-%d)[/COLOR]%s" % (nome, da, a, segno))
    scelta = xbmcgui.Dialog().select("Vai a un capitolo", righe)
    if scelta < 0:
        return
    nome, da, _a = archi[scelta]
    progresso.vai_a(pid, da)
    xbmcgui.Dialog().notification(
        "Le Saghe", "Sei all'inizio di: %s" % nome,
        xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.executebuiltin("Container.Refresh")


def salta(pid):
    totale = catalogo.lunghezza(pid)
    corrente = progresso.posizione(pid)
    scelta = xbmcgui.Dialog().numeric(
        0, "Tappa da cui ripartire (1-%d)" % totale, str(corrente))
    if not scelta:
        return
    try:
        n = max(1, min(int(scelta), totale))
    except ValueError:
        return
    progresso.vai_a(pid, n)
    xbmcgui.Dialog().notification(
        "Le Saghe", catalogo.descrizione_segmento(pid, n),
        xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.executebuiltin("Container.Refresh")


def elenco_film(pid):
    fl = schede.film(pid)
    xbmcplugin.setPluginCategory(
        MANIGLIA, "%s - i film" % catalogo.PERCORSI[pid]["titolo"])
    prima = catalogo.PERCORSI[pid]["segmenti"][0][0]
    fonte = fonti.fonte_migliore(prima, 1)
    for m in fl:
        anno = m.get("d") or "?"
        trama = m.get("p") or "Nessuna trama in italiano su TMDb."
        elenco = [f for f in m.get("f", []) if fonti.possiede(f)]
        if elenco:
            coda = "  [COLOR 997FA8D8]- %s[/COLOR]" % " / ".join(
                fonti.sigla(f) or f for f in elenco)
        elif m.get("f"):
            coda = "  [COLOR 99BBBBBB]- solo %s[/COLOR]" % " / ".join(
                fonti.sigla(f) or f for f in m["f"])
        else:
            coda = "  [COLOR red]- non in streaming[/COLOR]"
        li = _voce("%s  [COLOR grey](%s)[/COLOR]%s" % (m["t"], anno, coda),
                   "%s\n\n%s" % (m["t"], trama),
                   riproducibile=True)
        if elenco:
            lg = fonti.logo(elenco[0])
            if lg:
                li.setArt({"clearlogo": lg})
        if m.get("i"):
            li.setArt({"poster": m["i"], "thumb": m["i"], "icon": m["i"]})
        tag = li.getVideoInfoTag()
        tag.setMediaType("movie")
        tag.setTitle(m["t"])
        if anno.isdigit():
            tag.setYear(int(anno))
        if m.get("p"):
            tag.setPlot(m["p"])
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="apri_film", percorso=pid, titolo=m["t"]),
            li, False)
    xbmcplugin.setContent(MANIGLIA, "movies")
    xbmcplugin.endOfDirectory(MANIGLIA)


def apri_film(pid, titolo):
    prima = catalogo.PERCORSI[pid]["segmenti"][0][0]
    fonte = fonti.fonte_migliore(prima, 1)
    if fonte and fonte["tipo"] == "app":
        xbmcgui.Dialog().notification(
            "Le Saghe", "Cerca: %s" % titolo, xbmcgui.NOTIFICATION_INFO, 8000)
        fonti.avvia_app(catalogo.FONTI[fonte["id"]]["pacchetto"])
    else:
        xbmcgui.Dialog().ok(
            "Le Saghe",
            "Per questo film non c'è ancora una fonte configurata. %s"
            % titolo)
    xbmcplugin.setResolvedUrl(MANIGLIA, False, xbmcgui.ListItem())


def tagli(pid):
    """Elenco dei punti in cui l'Italia ha interrotto questa saga."""
    elenco = catalogo.tutti_i_tagli(pid)
    xbmcplugin.setPluginCategory(
        MANIGLIA, "%s - dove ti hanno interrotto" % catalogo.PERCORSI[pid]["titolo"])

    simboli = {"stop": "[COLOR red]# FERMATI QUI[/COLOR]",
               "salto": "[COLOR orange]* MAI TRASMESSO[/COLOR]",
               "nota": "[COLOR grey]- contesto[/COLOR]"}

    for idx, serie_id, tg in elenco:
        serie = catalogo.SERIE[serie_id]
        etichetta = "%s -  %s, episodio %d" % (
            simboli.get(tg["tipo"], ""), serie["titolo"], tg["ep"])

        descrizione = "%s\n\n%s\n\n[COLOR grey]Tappa %d della catena.[/COLOR]" % (
            etichetta.replace("[COLOR red]", "").replace("[COLOR orange]", "")
                     .replace("[COLOR grey]", "").replace("[/COLOR]", ""),
            tg["cosa"], idx)

        li = _voce(etichetta, descrizione, riproducibile=True)
        li.addContextMenuItems([
            ("Riparti da qui",
             "RunPlugin(%s)" % url(azione="vai", percorso=pid, idx=idx)),
        ])
        xbmcplugin.addDirectoryItem(
            MANIGLIA, url(azione="riproduci", percorso=pid, idx=idx), li, False)

    if not elenco:
        li = _voce("Nessun taglio documentato per questa saga.")
        xbmcplugin.addDirectoryItem(MANIGLIA, url(), li, False)

    xbmcplugin.endOfDirectory(MANIGLIA)


def spiega(pid):
    p = catalogo.PERCORSI[pid]
    righe = [p["spiegazione"], "", "[B]Come è composta la catena:[/B]"]
    n = 0
    for serie_id, primo, ultimo in p["segmenti"]:
        serie = catalogo.SERIE[serie_id]
        quanti = ultimo - primo + 1
        righe.append("- %s, episodi %d-%d  (tappe %d-%d)%s" % (
            serie["titolo"], primo, ultimo, n + 1, n + quanti,
            "" if serie["verificato"] else "  <- conteggio da confermare"))
        n += quanti
    righe.append("")
    righe.append("Totale: %d episodi." % n)
    xbmcgui.Dialog().textviewer(p["titolo"], "\n".join(righe))


def azzera(pid):
    if xbmcgui.Dialog().yesno(
            "Le Saghe",
            "Azzerare il progresso di [B]%s[/B]?\n"
            "Tornerai al primo episodio." % catalogo.PERCORSI[pid]["titolo"]):
        progresso.azzera(pid)
        xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------------------
# Instradamento
# --------------------------------------------------------------------------

def instrada(qs):
    p = dict(parse_qsl(qs[1:]))
    azione = p.get("azione")
    pid = p.get("percorso")

    if not azione:
        menu_principale()
    elif azione == "percorso":
        menu_percorso(pid)
    elif azione == "sfoglia":
        sfoglia(pid, p.get("da", 1))
    elif azione == "riproduci":
        riproduci(pid, p.get("idx", 1))
    elif azione == "salta":
        salta(pid)
    elif azione == "capitoli":
        capitoli(pid)
    elif azione == "russo":
        russo()
    elif azione == "russo_consiglio":
        russo_consiglio()
    elif azione == "russo_guarda":
        russo_guarda(p.get("canale", ""))
    elif azione == "abbonamenti":
        pannello_abbonamenti()
    elif azione == "altro":
        menu_altro(pid)
    elif azione == "film":
        elenco_film(pid)
    elif azione == "apri_film":
        apri_film(pid, p.get("titolo", ""))
    elif azione == "tagli":
        tagli(pid)
    elif azione == "spiega":
        spiega(pid)
    elif azione == "azzera":
        azzera(pid)
    elif azione == "vai":
        progresso.vai_a(pid, int(p["idx"]))
        xbmc.executebuiltin("Container.Refresh")
    elif azione == "visto":
        progresso.segna_visto(pid, int(p["idx"]), avanza=False)
        xbmc.executebuiltin("Container.Refresh")
    elif azione == "nonvisto":
        progresso.togli_visto(pid, int(p["idx"]))
        xbmc.executebuiltin("Container.Refresh")
    elif azione == "anomalie":
        an = progresso.anomalie()
        righe = []
        for a in an[::-1]:
            righe.append("%s\n   chiesto:  %s\n   partito:  %s\n"
                         % (a["quando"], a["atteso"], a["ottenuto"]))
        xbmcgui.Dialog().textviewer(
            "Episodi sbagliati", "\n".join(righe) or "Nessuna anomalia.")
    elif azione == "impostazioni":
        ADDON.openSettings()
    else:
        menu_principale()


if __name__ == "__main__":
    instrada(sys.argv[2])
