# -*- coding: utf-8 -*-
"""
Catalogo delle serie e catene cronologiche.

Una CATENA e' una sequenza di segmenti (serie, primo_ep, ultimo_ep) che,
appiattita, produce l'ordine reale in cui gli episodi vanno guardati.
L'indice di catena e' 1-based e non si azzera mai fra una serie e l'altra:
e' quello che permette il "continua sempre col successivo" anche quando il
successivo sta in un'altra serie.

Ogni conteggio di episodi porta un flag `verificato`. Al 04/09/2026 sono
tutti True: confrontati uno per uno con TMDb e tutti coincidenti.
"""

# --------------------------------------------------------------------------
# Fonti: dove sta materialmente il video.
#   tipo "app"    -> apre un'applicazione Android del box
#   tipo "plugin" -> riproduce dentro Kodi tramite un altro addon
#   tipo "web"    -> non riproducibile qui, serve un browser o un'app assente
# --------------------------------------------------------------------------

FONTI = {
    "netflix": {
        "etichetta": "Netflix",
        "tipo": "app",
        "pacchetto": "com.netflix.ninja",
        "gratis": False,
        "logo": "netflix",
        "sigla": "Netflix",
        "deeplink": "https://www.netflix.com/title/%s",
        "chiave_abbonamento": "ha_netflix",
    },
    "prime": {
        "etichetta": "Prime Video",
        "tipo": "app",
        "pacchetto": "com.amazon.avod.thirdpartyclient",
        "gratis": False,
        "logo": "prime",
        "sigla": "Prime",
        "deeplink": "",
        "chiave_abbonamento": "ha_prime",
    },
    "disney": {
        "etichetta": "Disney+",
        "tipo": "app",
        "pacchetto": "com.disney.disneyplus",
        "gratis": False,
        "logo": "disney",
        "sigla": "Disney+",
        "deeplink": "",
        "chiave_abbonamento": "ha_disney",
    },
    "crunchyroll": {
        "etichetta": "Crunchyroll",
        "tipo": "app",
        "pacchetto": "com.crunchyroll.crunchyroid",
        "gratis": False,
        "logo": "crunchyroll",
        "sigla": "Crunchyroll",
        "deeplink": "",
        "chiave_abbonamento": "ha_crunchyroll",
    },
    "timvision": {
        "etichetta": "Timvision",
        "tipo": "app",
        "pacchetto": "it.telecomitalia.timvision",
        "gratis": False,
        "chiave_abbonamento": "ha_timvision",
        "logo": "",
        "sigla": "Timvision",
        "deeplink": "",
    },
    "animegeneration": {
        "etichetta": "Anime Generation (canale Prime a pagamento)",
        "tipo": "app",
        "pacchetto": "com.amazon.avod.thirdpartyclient",
        "gratis": False,
        "chiave_abbonamento": "ha_animegeneration",
        "logo": "animegeneration",
        "sigla": "AnimeGen",
        "deeplink": "",
    },
    "infinity": {
        "etichetta": "Mediaset Infinity (gratis)",
        "tipo": "app",
        "pacchetto": "it.mediaset.infinity",
        "gratis": True,
        "logo": "infinity",
        "sigla": "Infinity",
        "deeplink": "",
        "chiave_abbonamento": None,
    },
    "youtube": {
        "etichetta": "YouTube - Yamato (gratis)",
        "tipo": "plugin",
        "pacchetto": "plugin.video.youtube",
        "gratis": True,
        "logo": "",
        "sigla": "YouTube",
        "deeplink": "",
        "chiave_abbonamento": None,
    },
    "pluto": {
        "etichetta": "Pluto TV (gratis)",
        "tipo": "plugin",
        "pacchetto": "plugin.video.plutotv",
        "gratis": True,
        "logo": "pluto",
        "sigla": "Pluto",
        "deeplink": "",
        "chiave_abbonamento": None,
    },
}


# --------------------------------------------------------------------------
# Serie
# --------------------------------------------------------------------------

SERIE = {
    # ---- Dragon Ball ----
    "db": {
        "titolo": "Dragon Ball",
        "anni": "1986-1989",
        "episodi": 153,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration"],
        "nota": "Da Goku bambino fino al torneo con Piccolo.",
    },
    "dbz": {
        "titolo": "Dragon Ball Z",
        "anni": "1989-1996",
        "episodi": 291,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration"],
        "nota": "Stessa storia di Dragon Ball, senza interruzione: "
                "Toei spezzo' la messa in onda quando Goku divento' adulto.",
    },
    "daima": {
        "titolo": "Dragon Ball Daima",
        "anni": "2024-2025",
        "episodi": 20,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["netflix", "crunchyroll", "animegeneration"],
        "id_netflix": "81943491",
        "nota": "Ambientata un anno dopo Majin Bu. L'ultima cosa scritta da "
                "Toriyama. E' L'UNICA delle tue serie che sta su Netflix.",
    },
    "dbs": {
        "titolo": "Dragon Ball Super",
        "anni": "2015-2018",
        "episodi": 131,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration"],
        "nota": "Beerus e Champa agli episodi 28-46. Torneo del Potere con Jiren dal 96.",
    },
    "gt": {
        "titolo": "Dragon Ball GT",
        "anni": "1996-1997",
        "episodi": 64,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration"],
        "nota": "Continuazione alternativa, non canonica. "
                "Il Super Saiyan di quarto livello esiste solo qui.",
    },

    "dbz_kai": {
        "titolo": "Dragon Ball Z Kai",
        "anni": "2009-2015",
        "episodi": 158,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Dragon Ball Z rimontato: stessa storia, riempitivo tagliato, "
                "immagine restaurata. 291 episodi diventano 158.",
    },

    # ---- I Cavalieri dello Zodiaco ----
    "ss": {
        "titolo": "I Cavalieri dello Zodiaco",
        "anni": "1986-1989",
        "episodi": 114,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration", "timvision"],
        "nota": "In Italia la trasmissione fu interrotta due volte all'episodio 52.",
    },
    "ss_hades": {
        "titolo": "I Cavalieri dello Zodiaco - Hades",
        "anni": "2002-2008",
        "episodi": 31,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Il vero finale in tre blocchi, confermati da TMDb: "
                "Santuario 13 episodi, Inferno 12, Elysion 6.",
    },

    # ---- Ken il guerriero ----
    "ken1": {
        "titolo": "Ken il guerriero",
        "anni": "1984-1987",
        "episodi": 109,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration", "crunchyroll"],
        "nota": "Prima serie.",
    },
    "ken2": {
        "titolo": "Ken il guerriero II",
        "anni": "1987-1988",
        "episodi": 43,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration", "crunchyroll"],
        "nota": "Seconda serie. Caio, il fratello di Raoul, compare "
                "dall'episodio 24 al 43: e' l'ultimo arco animato.",
    },

    # ---- Holly e Benji ----
    "holly": {
        "titolo": "Holly e Benji, due fuoriclasse",
        "anni": "1983-1986",
        "episodi": 128,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "La serie originale.",
    },
    "holly2": {
        "titolo": "Che campioni Holly e Benji",
        "anni": "1994-1995",
        "episodi": 47,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["infinity", "timvision"],
        "nota": "GRATIS e completa su Mediaset Infinity, sezione "
                "Animazione Made in Japan. Verificato il 04/09/2026.",
    },

    # ---- Mazinga ----
    "mazinga": {
        "titolo": "Mazinga Z",
        "anni": "1972-1974",
        "episodi": 92,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "In Italia arrivo' in ordine sparso e con episodi mancanti.",
    },
    "mazinga_edition_z": {
        "titolo": "Mazinger Edition Z: The Impact!",
        "anni": "2009",
        "episodi": 26,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["animegeneration"],
        "nota": "La rilettura moderna.",
    },
    # ---- Go Nagai: i robot che aprirono la strada in Italia (1978-1980) ----
    "grande_mazinga": {
        "titolo": "Il Grande Mazinga",
        "anni": "1974-1975",
        "episodi": 56,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Comincia dove finisce Mazinga Z: e' un seguito diretto, "
                "non una serie a parte.",
    },
    "goldrake": {
        "titolo": "UFO Robot Goldrake",
        "anni": "1975-1977",
        "episodi": 74,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "In Giappone e' il terzo capitolo della stessa saga; in Italia "
                "arrivo' per primo, nel 1978, e per questo sembra un'opera a se'.",
    },
    "jeeg": {
        "titolo": "Jeeg robot d'acciaio",
        "anni": "1975-1976",
        "episodi": 46,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Stesso autore, storia separata: si guarda quando si vuole.",
    },

    # ---- Lupin III: tre serie, riconoscibili dal colore della giacca ----
    "lupin1": {
        "titolo": "Le avventure di Lupin III",
        "anni": "1971-1972",
        "episodi": 23,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "La prima serie, giacca VERDE. Piu' adulta e cupa delle altre.",
    },
    "lupin2": {
        "titolo": "Le nuove avventure di Lupin III",
        "anni": "1977-1980",
        "episodi": 155,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Giacca ROSSA. E' quella che in Italia hanno visto tutti.",
    },
    "lupin3": {
        "titolo": "Lupin III (terza serie)",
        "anni": "1984-1985",
        "episodi": 50,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Giacca ROSA. La piu' sopra le righe delle tre.",
    },

    # ---- Le maghette dello studio Pierrot: quattro serie sorelle ----

    # ---- Kiss Me Licia e i quattro seguiti dal vero (il groviglio famoso) ----

    # ---- Naruto: tre serie di fila, una storia sola ----
    "naruto": {
        "titolo": "Naruto",
        "anni": "2002-2007",
        "episodi": 220,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["prime"],
        "nota": "Naruto bambino. Dall'episodio 136 in poi e' quasi tutto "
                "riempitivo: la storia vera riprende con Shippuden.",
    },
    "naruto_shippuden": {
        "titolo": "Naruto Shippuden",
        "anni": "2007-2017",
        "episodi": 500,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["prime"],
        "nota": "Il seguito diretto, due anni e mezzo dopo. Stessa storia, "
                "non una serie nuova.",
    },
    "boruto": {
        "titolo": "Boruto: Naruto Next Generations",
        "anni": "2017-2023",
        "episodi": 293,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "La generazione dopo: protagonista il figlio di Naruto.",
    },

    # ---- One Piece: una sola serie, ma lunghissima ----
    "one_piece": {
        "titolo": "One Piece",
        "anni": "1999-oggi",
        "episodi": 1181,
        "verificato": True,
        "audio_ita": True,
        "fonti": ["netflix", "prime"],
        "nota": "Non ha seguiti ne' rifacimenti da incastrare: il problema "
                "qui non e' l'ordine, e' orientarsi in milleduecento episodi.",
    },

    # ---- Gundam: la saga dell'Universal Century, in ordine di storia ----
    "gundam0079": {
        "titolo": "Mobile Suit Gundam",
        "anni": "1979-1980",
        "episodi": 43,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "L'originale: la guerra di un anno. Da qui parte tutto.",
    },
    "zeta_gundam": {
        "titolo": "Mobile Suit Zeta Gundam",
        "anni": "1985-1986",
        "episodi": 50,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Sette anni dopo l'originale. Seguito diretto, stessi personaggi.",
    },
    "gundam_zz": {
        "titolo": "Mobile Suit Gundam ZZ",
        "anni": "1986-1987",
        "episodi": 47,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Riprende il giorno dopo la fine di Zeta.",
    },

    # ---- L'universo di Leiji Matsumoto ----
    "harlock": {
        "titolo": "Capitan Harlock",
        "anni": "1978-1979",
        "episodi": 42,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Il pirata dello spazio. Stesso universo del Galaxy Express: "
                "i personaggi si incrociano.",
    },
    "galaxy999": {
        "titolo": "Galaxy Express 999",
        "anni": "1978-1981",
        "episodi": 113,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "Il treno che attraversa la galassia. Maetel ed Emeraldas "
                "legano questa storia a quella di Harlock.",
    },

    # ---- Rumiko Takahashi ----
    "lamu": {
        "titolo": "Lamu",
        "anni": "1981-1986",
        "episodi": 218,
        "verificato": True,
        "audio_ita": True,
        "fonti": [],
        "nota": "In originale Urusei Yatsura. Non ha una trama che avanza: "
                "si guarda in qualunque ordine, l'ordine serve solo a non "
                "perdere il filo dei personaggi che si aggiungono.",
    },

}


# --------------------------------------------------------------------------
# I TAGLI ITALIANI
#
# Il cuore del progetto: dove la televisione italiana ha staccato la spina.
# Chiave = id serie, valore = elenco di eventi ancorati a un episodio.
#   ep    episodio a cui si riferisce
#   tipo  "stop" (da qui non si andò oltre) | "salto" (episodio mai trasmesso)
#         | "nota" (contesto)
#   cosa  cosa successe, in italiano leggibile
# --------------------------------------------------------------------------

TAGLI = {
    "db": [
        {"ep": 54, "tipo": "stop", "verificato": True,
         "cosa": "Junior TV, prima trasmissione italiana (1996-1998): si fermò "
                 "qui, ai primi 54 episodi."},
        {"ep": 99, "tipo": "stop", "verificato": True,
         "cosa": "Mediaset comprò i diritti solo delle prime 99 puntate su 153 "
                 "e le fece ridoppiare da Merak. Oltre questo punto, per anni, "
                 "in italiano non esisteva niente."},
    ],
    "dbz": [
        {"ep": 79, "tipo": "salto", "verificato": True,
         "cosa": "Eliminato dalle repliche su Italia 1 del 2012: ritenuto "
                 "troppo violento."},
        {"ep": 80, "tipo": "salto", "verificato": True,
         "cosa": "Eliminato dalle repliche su Italia 1 del 2012."},
        {"ep": 85, "tipo": "salto", "verificato": True,
         "cosa": "Eliminato dalle repliche su Italia 1 del 2012."},
    ],
    "ss": [
        {"ep": 52, "tipo": "stop", "verificato": True,
         "cosa": "IL TAGLIO CHE RICORDI. Odeon TV interruppe qui la "
                 "trasmissione, mentre Pegasus affronta Ioria di Leo - e lo "
                 "fece DUE VOLTE, ricominciando ogni volta dall'episodio 1. "
                 "Se non hai mai visto oltre, il motivo è questo."},
        {"ep": 74, "tipo": "nota", "verificato": True,
         "cosa": "Comincia la saga di Asgard, acquistata dalla Fininvest e "
                 "trasmessa su Italia 7 col titolo 'Il ritorno dei Cavalieri "
                 "dello zodiaco'."},
    ],
    "ss_hades": [
        {"ep": 1, "tipo": "nota", "verificato": True,
         "cosa": "Il capitolo di Hades arrivò in italiano solo nel 2008, su "
                 "Italia 1 la domenica mattina: diciotto anni dopo il taglio "
                 "dell'episodio 52."},
    ],
    "ken1": [
        {"ep": 1, "tipo": "nota", "verificato": True,
         "cosa": "In Italia arrivò nel 1988, e non su Rai o Mediaset ma su "
                 "emittenti locali private: per questo lo trovavi a orari "
                 "improbabili e a singhiozzo."},
    ],
    "ken2": [
        {"ep": 43, "tipo": "nota", "verificato": True,
         "cosa": "Qui finisce il cartone, ma NON il fumetto: i tre archi "
                 "narrativi conclusivi non furono mai animati, in nessuna "
                 "lingua. Questo pezzo esiste solo a fumetti."},
    ],
    "mazinga": [
        {"ep": 4, "tipo": "salto", "verificato": True,
         "cosa": "Saltato dalla Rai nel 1980: mai trasmesso."},
        {"ep": 5, "tipo": "salto", "verificato": True,
         "cosa": "Saltato dalla Rai nel 1980: mai trasmesso."},
        {"ep": 14, "tipo": "salto", "verificato": True,
         "cosa": "Saltato dalla Rai nel 1980: mai trasmesso."},
        {"ep": 28, "tipo": "salto", "verificato": True,
         "cosa": "Saltato dalla Rai nel 1980: mai trasmesso."},
        {"ep": 38, "tipo": "salto", "verificato": True,
         "cosa": "Saltato dalla Rai nel 1980: mai trasmesso."},
        {"ep": 56, "tipo": "stop", "verificato": True,
         "cosa": "QUI LA RAI SI FERMÒ, nel 1980. In tutto andarono in onda 51 "
                 "episodi su 92, ognuno tagliato di circa tre minuti. Il "
                 "motivo furono le polemiche contro i cartoni giapponesi "
                 "esplose in Italia nell'aprile di quell'anno."},
        {"ep": 57, "tipo": "nota", "verificato": True,
         "cosa": "Da qui in poi, 41 episodi rimasti INEDITI in italiano per "
                 "trentacinque anni: sono stati doppiati per la prima volta "
                 "solo nel 2015. Nessuno della tua generazione li ha visti da "
                 "ragazzo, perché non esistevano."},
    ],
    "holly": [
        {"ep": 65, "tipo": "nota", "verificato": True,
         "cosa": "Nell'edizione italiana gli episodi 65 e 66 sono invertiti "
                 "rispetto all'originale."},
    ],
}


def tagli_di(serie_id, ep):
    """Eventi di taglio riferiti a questo esatto episodio."""
    return [t for t in TAGLI.get(serie_id, []) if t["ep"] == ep]


def tutti_i_tagli(percorso_id):
    """Tagli del percorso, con l'indice di catena calcolato.

    Restituisce una lista ordinata di (idx, serie_id, taglio).
    """
    fuori = []
    for t in catena(percorso_id):
        for taglio in tagli_di(t["serie"], t["ep"]):
            fuori.append((t["idx"], t["serie"], taglio))
    return fuori


# --------------------------------------------------------------------------
# Catene cronologiche
#
# Ogni segmento e' (id_serie, primo_episodio, ultimo_episodio).
# L'ordine dei segmenti E' l'ordine di visione.
# --------------------------------------------------------------------------

PERCORSI = {
    "dragonball": {
        "titolo": "Dragon Ball",
        "sottotitolo": "La storia completa, in ordine cronologico",
        "segmenti": [
            ("db",    1, 153),
            ("dbz",   1, 288),
            ("daima", 1,  20),
            ("dbs",   1, 131),
            ("dbz", 289, 291),
            ("gt",    1,  64),
        ],
        "spiegazione": (
            "Dragon Ball e Dragon Ball Z sono lo stesso fumetto: il confine non "
            "esiste nell'originale. Super non viene DOPO Z, viene DENTRO Z, nel "
            "salto di dieci anni: per questo Z si interrompe all'episodio 288 e "
            "riprende col 289 solo dopo Daima e Super. GT chiude come finale "
            "alternativo: fu prodotta nel 1996, prima che Super esistesse."
        ),
    },

    "dragonball_veloce": {
        "titolo": "Dragon Ball - via veloce",
        "sottotitolo": "Stessa storia senza riempitivo, con Kai al posto di Z",
        "segmenti": [
            ("db",      1, 153),
            ("dbz_kai", 1, 158),
            ("daima",   1,  20),
            ("dbs",     1, 131),
            ("gt",      1,  64),
        ],
        "spiegazione": (
            "Identica alla via integrale, ma al posto dei 291 episodi di "
            "Dragon Ball Z usa i 158 di Kai: e' lo stesso Z rimontato nel 2009 "
            "senza le puntate di riempimento, con immagine restaurata. Si "
            "risparmiano 133 episodi e non si perde nulla della trama. Kai "
            "copre anche il finale, quindi qui non c'e' il rientro degli "
            "episodi 289-291. Le due vie hanno progressi separati: puoi "
            "tenerle entrambe senza che si disturbino."
        ),
    },

    "zodiaco": {
        "titolo": "I Cavalieri dello Zodiaco",
        "sottotitolo": "Dal Santuario fino al finale mai trasmesso",
        "segmenti": [
            ("ss",       1, 114),
            ("ss_hades", 1,  31),
        ],
        "spiegazione": (
            "Il Santuario sta negli episodi 1-73, Asgard nel 74-99, Nettuno nel "
            "100-114. In Italia ti hanno fermato all'episodio 52, due volte. "
            "Tutto cio' che segue e' materiale che non hai mai visto."
        ),
    },

    "ken": {
        "titolo": "Ken il guerriero",
        "sottotitolo": "Le due serie anni Ottanta, di fila",
        "segmenti": [
            ("ken1", 1, 109),
            ("ken2", 1,  43),
        ],
        "spiegazione": (
            "Centocinquantadue episodi in tutto. In Italia arrivarono spezzati "
            "e a distanza di anni."
        ),
    },

    "holly": {
        "titolo": "Holly e Benji",
        "sottotitolo": "La serie originale e il seguito",
        "segmenti": [
            ("holly",  1, 128),
            ("holly2", 1,  47),
        ],
        "spiegazione": (
            "Il seguito e' gratuito e completo su Mediaset Infinity: e' la cosa "
            "piu' facile da recuperare di tutto l'elenco."
        ),
    },

    "mazinga": {
        "titolo": "Mazinga",
        "sottotitolo": "L'originale e la rilettura moderna",
        "segmenti": [
            ("mazinga",           1, 92),
            ("mazinga_edition_z", 1, 26),
        ],
        "spiegazione": (
            "Mazinga Z originale, poi la rilettura del 2009."
        ),
    },
    "gonagai": {
        "titolo": "I robot di Go Nagai",
        "sottotitolo": "Mazinga, il Grande Mazinga e Goldrake sono UNA storia sola",
        "segmenti": [
            ("mazinga",        1, 92),
            ("grande_mazinga", 1, 56),
            ("goldrake",       1, 74),
        ],
        "spiegazione": (
            "In Giappone sono tre capitoli consecutivi della stessa saga: il "
            "Grande Mazinga comincia esattamente dove Mazinga Z finisce, e "
            "Goldrake chiude. In Italia arrivarono al contrario - Goldrake nel "
            "1978 per primo, gli altri due dopo - e per questo sembrano tre "
            "cose separate. Guardati in quest'ordine tornano una storia sola. "
            "Jeeg e' dello stesso autore ma vive per conto suo: sta fuori."
        ),
    },

    "lupin": {
        "titolo": "Lupin III",
        "sottotitolo": "Le tre serie storiche, riconoscibili dalla giacca",
        "segmenti": [
            ("lupin1", 1,  23),
            ("lupin2", 1, 155),
            ("lupin3", 1,  50),
        ],
        "spiegazione": (
            "Non c'e' una trama che continua: Lupin si guarda in qualunque "
            "ordine. L'ordine di produzione pero' racconta come cambio' il "
            "personaggio, e lo riconosci dal colore della giacca: VERDE la "
            "prima (1971, la piu' adulta), ROSSA la seconda (1977, quella che "
            "in Italia hanno visto tutti), ROSA la terza (1984, la piu' sopra "
            "le righe)."
        ),
    },



    "naruto": {
        "titolo": "Naruto",
        "sottotitolo": "Le tre serie di fila: Naruto, Shippuden, Boruto",
        "segmenti": [
            ("naruto",           1, 220),
            ("naruto_shippuden", 1, 500),
            ("boruto",           1, 293),
        ],
        "spiegazione": (
            "Non sono tre storie: e' una sola, spezzata dalla produzione. "
            "Shippuden riprende esattamente dove Naruto finisce, due anni e "
            "mezzo dopo nella storia. Boruto viene dopo l'epilogo, con il "
            "figlio come protagonista: si puo' anche non guardarlo, la storia "
            "di Naruto si chiude prima.\n\n"
            "ATTENZIONE AL RIEMPITIVO: gli episodi 136-220 della prima serie "
            "sono quasi tutti inventati per far tempo, e la storia vera non "
            "avanza. Molti li saltano e passano direttamente a Shippuden."
        ),
    },

    "one_piece": {
        "titolo": "One Piece",
        "sottotitolo": "Milleduecento episodi, divisi per isole e per saghe",
        "segmenti": [
            ("one_piece", 1, 1181),
        ],
        "spiegazione": (
            "Qui non c'e' niente da riordinare: e' una serie sola, in ordine. "
            "Il problema e' un altro - sono milleduecento episodi e senza "
            "punti di riferimento non si sa mai dove si e'. Per questo la "
            "saga e' divisa nei suoi archi: ognuno e' un'isola o una guerra, "
            "e si puo' saltare da uno all'altro senza scorrere."
        ),
    },

    "gundam": {
        "titolo": "Gundam - Universal Century",
        "sottotitolo": "Le tre serie storiche, in ordine di storia",
        "segmenti": [
            ("gundam0079", 1, 43),
            ("zeta_gundam", 1, 50),
            ("gundam_zz",   1, 47),
        ],
        "spiegazione": (
            "Gundam e' un guaio perche' esistono decine di serie ambientate in "
            "universi diversi che non c'entrano niente fra loro. Queste tre "
            "invece sono UNA storia sola, lo stesso calendario (lo chiamano "
            "Universal Century) e in gran parte gli stessi personaggi: Zeta "
            "comincia sette anni dopo l'originale, e ZZ riprende il giorno "
            "dopo la fine di Zeta. Tutto il resto che porta il nome Gundam "
            "sta fuori: non serve averlo visto."
        ),
    },

    "matsumoto": {
        "titolo": "L'universo di Capitan Harlock",
        "sottotitolo": "Harlock e il Galaxy Express: due storie, un mondo solo",
        "segmenti": [
            ("harlock",    1,  42),
            ("galaxy999",  1, 113),
        ],
        "spiegazione": (
            "Non e' un seguito: sono due serie parallele dello stesso autore, "
            "ambientate nello stesso universo. Maetel ed Emeraldas passano "
            "dall'una all'altra, e Harlock compare sul treno. Guardando prima "
            "Harlock si riconoscono le comparse quando arrivano nel 999."
        ),
    },

    "lamu": {
        "titolo": "Lamu",
        "sottotitolo": "218 episodi senza una trama obbligata",
        "segmenti": [
            ("lamu", 1, 218),
        ],
        "spiegazione": (
            "Qui non c'e' un ordine da rispettare: ogni episodio si chiude da "
            "solo. L'ordine serve solo a vedere i personaggi arrivare uno per "
            "volta invece di trovarseli gia' tutti in scena."
        ),
    },

    "naruto_veloce": {
        "titolo": "Naruto - senza riempitivo",
        "sottotitolo": "Solo la storia vera: 427 episodi invece di 720",
        "segmenti": [
            # Naruto: 130 episodi su 220
            ("naruto",   1,  25),
            ("naruto",  27,  96),
            ("naruto",  98, 100),
            ("naruto", 107, 135),
            ("naruto", 141, 142),
            ("naruto", 220, 220),
            # Shippuden: 297 episodi su 500
            ("naruto_shippuden",   1,  56),
            ("naruto_shippuden",  72,  90),
            ("naruto_shippuden", 113, 143),
            ("naruto_shippuden", 152, 169),
            ("naruto_shippuden", 172, 175),
            ("naruto_shippuden", 197, 222),
            ("naruto_shippuden", 243, 256),
            ("naruto_shippuden", 261, 270),
            ("naruto_shippuden", 272, 278),
            ("naruto_shippuden", 282, 283),
            ("naruto_shippuden", 296, 302),
            ("naruto_shippuden", 321, 346),
            ("naruto_shippuden", 362, 375),
            ("naruto_shippuden", 378, 387),
            ("naruto_shippuden", 391, 393),
            ("naruto_shippuden", 414, 415),
            ("naruto_shippuden", 418, 421),
            ("naruto_shippuden", 424, 426),
            ("naruto_shippuden", 451, 463),
            ("naruto_shippuden", 469, 479),
            ("naruto_shippuden", 484, 500),
        ],
        "spiegazione": (
            "Naruto e' famoso per il riempitivo: episodi inventati dallo studio "
            "per non superare il fumetto, dove la storia non avanza di un passo. "
            "Sono 293 episodi su 720, piu' di un terzo.\n\n"
            "Qui restano solo il canone del fumetto e gli episodi MISTI, quelli "
            "che mescolano storia vera e riempitivo e quindi non si possono "
            "saltare senza perdere pezzi.\n\n"
            "I blocchi non sono a occhio: vengono da un elenco che classifica "
            "tutti e 720 gli episodi uno per uno. Boruto non c'e': se lo vuoi, "
            "sta nel percorso Naruto completo."
        ),
    },

}

# L'ORDINE IN CUI COMPAIONO NEL MENU.
# Non e' alfabetico ne' cronologico: davanti quello che l'utente guarda di
# piu', e ogni saga "veloce" subito sotto la sua completa, cosi' si vede che
# sono due strade per la stessa storia.
# ATTENZIONE: una saga aggiunta a PERCORSI ma non messa qui NON SI VEDE.
ORDINE_PERCORSI = [
    "dragonball", "dragonball_veloce",
    "naruto", "naruto_veloce",
    "one_piece",
    "zodiaco",
    "ken",
    "holly",
    "gonagai", "mazinga",
    "lupin",
    "gundam",
    "matsumoto",
    "lamu",
]


# --------------------------------------------------------------------------
# Appiattimento della catena
# --------------------------------------------------------------------------

_cache_catene = {}


def catena(percorso_id):
    """Restituisce la lista ordinata delle tappe del percorso.

    Ogni tappa e' un dict:
        idx        posizione nella catena, 1-based, continua fra le serie
        serie      id della serie
        ep         numero dell'episodio dentro la sua serie
        etichetta  come mostrarlo all'utente
    """
    if percorso_id in _cache_catene:
        return _cache_catene[percorso_id]

    percorso = PERCORSI.get(percorso_id)
    if not percorso:
        return []

    tappe = []
    idx = 0
    for serie_id, primo, ultimo in percorso["segmenti"]:
        serie = SERIE[serie_id]
        for ep in range(primo, ultimo + 1):
            idx += 1
            tappe.append({
                "idx": idx,
                "serie": serie_id,
                "ep": ep,
                "etichetta": "%s - Episodio %d" % (serie["titolo"], ep),
            })

    _cache_catene[percorso_id] = tappe
    return tappe


def lunghezza(percorso_id):
    return len(catena(percorso_id))


def tappa(percorso_id, idx):
    """Tappa per indice 1-based. None se fuori catena."""
    tappe = catena(percorso_id)
    if idx < 1 or idx > len(tappe):
        return None
    return tappe[idx - 1]


def descrizione_segmento(percorso_id, idx):
    """Testo che spiega dove ci si trova nella catena, es.
    'Dragon Ball Z, episodio 137 di 291 - tappa 290 di 659'."""
    t = tappa(percorso_id, idx)
    if not t:
        return ""
    serie = SERIE[t["serie"]]
    return "%s, episodio %d di %d - tappa %d di %d" % (
        serie["titolo"], t["ep"], serie["episodi"], t["idx"], lunghezza(percorso_id)
    )

# --------------------------------------------------------------------------
# ARCHI NARRATIVI
#
# In una catena da 659 tappe non si trova piu' niente: "dove sono gli episodi
# con Jiren?" e' una domanda legittima a cui l'elenco non sapeva rispondere.
# Qui ogni saga puo' dichiarare i suoi capitoli, con la PRIMA e l'ULTIMA tappa
# (numerate come le vede l'utente, non come stanno nelle serie originali).
# --------------------------------------------------------------------------

ARCHI = {
    "gundam": [
        ("La guerra di un anno (l'originale)",   1,  43),
        ("Zeta - la Gryps",                     44,  93),
        ("ZZ - dopo Zeta",                      94, 140),
    ],
    "matsumoto": [
        ("Capitan Harlock",                      1,  42),
        ("Galaxy Express 999",                  43, 155),
    ],

    "naruto": [
        ("Il Paese delle Onde",                     1,  19),
        ("L'esame di selezione dei Chunin",        20,  67),
        ("L'invasione di Konoha",                  68,  80),
        ("La ricerca di Tsunade",                  81, 106),
        ("Il recupero di Sasuke",                 107, 135),
        ("Riempitivo - si puo' saltare",          136, 220),
        ("Shippuden: il salvataggio di Gaara",    221, 252),
        ("Shippuden: Hidan e Kakuzu",             253, 291),
        ("Shippuden: sulle tracce di Itachi",     292, 363),
        ("Shippuden: l'assalto di Pain",          364, 395),
        ("Shippuden: l'incontro dei cinque Kage", 396, 441),
        ("Shippuden: la Quarta Guerra Ninja",     442, 699),
        ("Shippuden: l'epilogo",                  700, 720),
        ("Boruto: la nuova generazione",          721, 1013),
    ],
    "one_piece": [
        ("East Blue - l'inizio",                    1,   61),
        ("Alabasta",                               62,  135),
        ("Skypiea - l'isola nel cielo",           136,  206),
        ("Water Seven ed Enies Lobby",            207,  325),
        ("Thriller Bark",                         326,  384),
        ("Impel Down e Marineford - la guerra",   385,  516),
        ("L'isola degli uomini-pesce",            517,  574),
        ("Punk Hazard",                           575,  628),
        ("Dressrosa",                             629,  746),
        ("Zou",                                   747,  782),
        ("Whole Cake Island",                     783,  877),
        ("Il Levely (Reverie)",                   878,  889),
        ("Wano",                                  890, 1085),
        ("Egghead - la saga finale",             1086, 1181),
    ],

    "dragonball": [
        ("Goku bambino e le prime sfere",        1,  28),
        ("L'esercito del Fiocco Rosso",         29,  68),
        ("Il Grande Mago Piccolo",              69, 122),
        ("Il torneo con Junior",               123, 153),
        ("I Saiyan: Radish e Vegeta",          154, 188),
        ("Namek e Freezer",                    189, 260),
        ("Gli androidi e Cell",                261, 347),
        ("Majin Bu",                           348, 441),
        ("Daima",                              442, 461),
        ("Beerus, il dio della distruzione",   462, 475),
        ("La resurrezione di Freezer",         476, 488),
        ("Il torneo con l'Universo 6",         489, 507),
        ("Trunks del futuro e Black",          508, 537),
        ("Torneo del Potere - JIREN",          538, 592),
        ("L'epilogo: Uub",                     593, 595),
        ("GT - il finale alternativo",         596, 659),
    ],
    "ken": [
        ("Shin e la Sacra Scuola di Nanto",      1,  22),
        ("Raoul e i fratelli di Hokuto",        23, 109),
        ("La seconda serie: Bart e la Terra",  110, 152),
    ],
    "zodiaco": [
        ("Il Santuario",                         1,  73),
        ("Asgard",                              74,  99),
        ("Poseidone",                          100, 114),
        ("Hades - il finale mai trasmesso",    115, 145),
    ],
    "gonagai": [
        ("Mazinga Z",                            1,  92),
        ("Il Grande Mazinga",                   93, 148),
        ("UFO Robot Goldrake",                 149, 222),
    ],
    "lupin": [
        ("Prima serie - giacca verde",           1,  23),
        ("Seconda serie - giacca rossa",        24, 178),
        ("Terza serie - giacca rosa",          179, 228),
    ],
}


def archi_di(percorso_id):
    """I capitoli di questa saga, o lista vuota se non ne ha."""
    return ARCHI.get(percorso_id, [])


def arco_della_tappa(percorso_id, numero_tappa):
    """In quale capitolo cade questa tappa. None se la saga non ha capitoli."""
    for nome, da, a in ARCHI.get(percorso_id, []):
        if da <= numero_tappa <= a:
            return nome
    return None
